/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package ur_os.memory.freememorymagament;

/**
 *
 * @author super
 */
public enum FreeMemorySlotManagerType {
    FIRST_FIT,
    BEST_FIT,
    WORST_FIT,
    
    // New Memory Slot Manager
    NEXT_FIT
    
}
