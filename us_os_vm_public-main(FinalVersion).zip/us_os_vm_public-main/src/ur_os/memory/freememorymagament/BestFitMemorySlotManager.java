/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ur_os.memory.freememorymagament;

/**
 *
 * @author super
 */
public class BestFitMemorySlotManager extends FreeMemorySlotManager {
    
    public BestFitMemorySlotManager(int memSize) {
        // Initialize memory with total size
        super(memSize);
    }

    @Override
    public MemorySlot getSlot(int size) {
        MemorySlot bestSlot = null;

        // Look for the smallest block that is still big enough
        for (MemorySlot ms : list) {
            if (ms.getSize() >= size && (bestSlot == null || bestSlot.getSize() > ms.getSize())) {
                bestSlot = ms;
            }
        }

        if (bestSlot != null) {
            if (bestSlot.getSize() == size) {
                // Exact match: remove from list and return it
                list.remove(bestSlot);
                return bestSlot;
            } else {
                // Split the block: return a new allocated block, and adjust the original one
                return bestSlot.assignMemory(size);
            }
        }


        // No suitable block was found
        System.out.println("Error - Memory cannot allocate a slot big enough for the requested memory");
        return null;
    }
}