package ur_os.memory.freememorymagament;

/**
 *
 * @author super
 */
public class NextFitMemorySlotManager extends FreeMemorySlotManager {

    // Index where the last successful allocation was made.
    private int lastIndex;

    public NextFitMemorySlotManager(int memSize) {
        super(memSize);
        this.lastIndex = 0;
    }

    @Override
    public MemorySlot getSlot(int size) {
        MemorySlot m = null;
        int n = list.size();
        if(n == 0) {
            System.out.println("Error - No slots available in the list.");
            return null;
        }
        
        // A counter is used to track the number of evaluated slots and avoid an infinite loop.
        int evaluated = 0;
        int index = lastIndex;
        
        // Traverse the list in a circular manner
        while(evaluated < n) {
            MemorySlot memorySlot = list.get(index);
            
            if(memorySlot.canContain(size)) {
                if(memorySlot.getSize() == size) {
                    // If the requested size matches exactly, remove the slot from the list.
                    m = memorySlot;
                    list.remove(index);
                    // Update lastIndex to continue from the position of the removed slot.
                    lastIndex = index % (list.size() == 0 ? 1 : list.size());
                    return m;
                } else {
                    // If only part of the slot is used, create a new slot and update the existing one.
                    m = memorySlot.assignMemory(size);
                    lastIndex = index;
                    return m;
                }
            }
            // Move to the next index in circular fashion
            index = (index + 1) % n;
            evaluated++;
        }
        
        // If no suitable slot is found
        System.out.println("Error - Memory cannot allocate a slot big enough for the requested memory");
        return null;
    }
}