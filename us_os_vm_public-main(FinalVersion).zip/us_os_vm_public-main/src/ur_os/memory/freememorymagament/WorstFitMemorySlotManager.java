/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ur_os.memory.freememorymagament;

/**
 *
 * @author super
 */
public class WorstFitMemorySlotManager extends FreeMemorySlotManager {
    
    // Constructor initializes the memory with a given size
    public WorstFitMemorySlotManager(int memSize){
        super(memSize);
    }
    
    @Override
    public MemorySlot getSlot(int size) {
        MemorySlot worstSlot = null;

        // Search for the largest block that can fit the requested size
        for (MemorySlot ms : list) {
            if (ms.getSize() >= size && (worstSlot == null || worstSlot.getSize() < ms.getSize())) {
                worstSlot = ms;
            }
        }

        if (worstSlot != null) {
            if (worstSlot.getSize() == size) {
                // If the block exactly matches the requested size, remove it from the list and return it
                list.remove(worstSlot);
                return worstSlot;
            } else {
                // Otherwise, split the block and return a new MemorySlot with the requested size
                return worstSlot.assignMemory(size);
            }
        }

        // If no suitable block is found, return null and print an error
        System.out.println("Error - Memory cannot allocate a slot big enough for the requested memory");
        return null;
    }
}